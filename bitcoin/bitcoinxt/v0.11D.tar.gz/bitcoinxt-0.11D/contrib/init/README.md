Sample configuration files for:

SystemD: bitcoinxtd.service
Upstart: bitcoinxtd.conf
OpenRC:  bitcoinxtd.openrc
         bitcoinxtd.openrcconf
CentOS:  bitcoinxtd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
