import unittest

class Test_Account(unittest.TestCase):

    def test_bip32_account(self):
        self.assertTrue(True)

    def test_old_account(self):
        self.assertTrue(True)
