from trustedcoin import TrustedCoinPlugin

class Plugin(TrustedCoinPlugin):
    pass
