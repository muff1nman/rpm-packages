from electrum.i18n import _

fullname = 'Plot History'
description = _("Ability to plot transaction history in graphical mode.")
requires =  [('matplotlib', 'matplotlib')]
available_for = ['qt']
