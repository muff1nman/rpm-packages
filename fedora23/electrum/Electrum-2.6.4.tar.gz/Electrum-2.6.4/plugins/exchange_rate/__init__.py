from electrum.i18n import _

fullname = _("Exchange rates")
description = _("Exchange rates and currency conversion tools.")
available_for = ['qt','kivy']
