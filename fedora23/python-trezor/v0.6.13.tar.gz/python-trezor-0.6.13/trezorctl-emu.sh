#!/bin/sh
./trezorctl -t pipe -p /tmp/pipe.trezor $*
