#!/bin/bash

python -m unittest discover
