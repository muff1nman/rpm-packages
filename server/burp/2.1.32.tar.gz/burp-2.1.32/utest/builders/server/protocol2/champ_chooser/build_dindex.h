#ifndef _BUILDER_SERVER_PROTOCOL2_DINDEX
#define _BUILDER_SERVER_PROTOCOL2_DINDEX

extern void build_dindex(uint64_t *di, size_t s, const char *fname);

#endif
