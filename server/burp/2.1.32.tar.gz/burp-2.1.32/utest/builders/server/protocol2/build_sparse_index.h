#ifndef _BUILDER_SERVER_PROTOCOL2_SPARSE
#define _BUILDER_SERVER_PROTOCOL2_SPARSE

extern void build_sparse_index(const char *path,
	int manifests, int fingerprints);

#endif
