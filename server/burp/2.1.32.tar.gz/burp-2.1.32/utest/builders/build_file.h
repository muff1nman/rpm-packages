#ifndef _BUILD_FILE_H
#define _BUILD_FILE_H

extern void build_file(const char *path, const char *content);

#endif
