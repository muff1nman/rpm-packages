#ifndef _BACKUP_PHASE3_SERVER_H
#define _BACKUP_PHASE3_SERVER_H

extern int backup_phase3_server_all(struct sdirs *sdirs, struct conf **confs);

#endif
