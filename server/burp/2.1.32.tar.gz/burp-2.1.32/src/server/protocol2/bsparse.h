#ifndef _BSPARSE_H
#define _BSPARSE_H

extern int run_bsparse(int argc, char *argv[]);

#endif
