#ifndef _BLOCKLEN_H
#define _BLOCKLEN_H

extern size_t get_librsync_block_len(const char *endfile);

#endif
