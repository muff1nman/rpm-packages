#ifndef _BEDUP_H 
#define _BEDUP_H 

extern int run_bedup(int argc, char *argv[]);

#endif
