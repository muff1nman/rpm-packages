#ifndef _LIST_CLIENT_H
#define _LIST_CLIENT_H

extern int do_list_client(struct asfd *asfd,
	enum action act, struct conf **confs);

#endif
