#ifndef _DELETE_CLIENT_H
#define _DELETE_CLIENT_H

extern int do_delete_client(struct asfd *asfd, struct conf **confs);

#endif
