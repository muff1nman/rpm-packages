#ifndef _GLOB_WINDOWS_H
#define _GLOB_WINDOWS_H

#ifdef HAVE_WIN32
extern int glob_windows(struct conf **confs);
#endif

#endif
