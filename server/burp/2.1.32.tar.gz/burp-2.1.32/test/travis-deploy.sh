#!/bin/bash
#
# This script only exists to keep Travis' deploy section happy.

echo "success"

exit 0
